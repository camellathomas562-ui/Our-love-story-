function showLove() {
  document.getElementById("message").innerHTML =
    "You are the sweetest part of my story. ❤️ I’m so lucky to have you in my life. 💕";
}function showLove() {
  document.getElementById("lovePopup").style.display = "flex";
}

function closeLove() {
  document.getElementById("lovePopup").style.display = "none";
}function sendMessage() {
  const name = document.getElementById("name").value;
  const message = document.getElementById("loveMessage").value;

  if (name === "" || message === "") {
    document.getElementById("sentMessage").innerHTML =
      "💕 Please fill in both boxes.";
    return;
  }

  document.getElementById("sentMessage").innerHTML =
    "Thank you, " + name + "! Your sweet message means so much. ❤️";
}